import React from 'react'

const AICoverLetterPage = () => {
  return (
    <div>
      AICoverLetterPage
    </div>
  )
}

export default AICoverLetterPage
