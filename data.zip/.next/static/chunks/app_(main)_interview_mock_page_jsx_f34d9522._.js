(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_interview_mock_page_jsx_f34d9522._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_interview_mock_page_jsx_f34d9522._.js",
  "chunks": [
    "static/chunks/_57291c97._.js"
  ],
  "source": "dynamic"
});
