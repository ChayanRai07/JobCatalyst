(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_resume_page_jsx_2dfa482d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_resume_page_jsx_2dfa482d._.js",
  "chunks": [
    "static/chunks/node_modules_33a43796._.js",
    "static/chunks/_7fccdcba._.js",
    "static/chunks/node_modules_date-fns_883ff725._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
    "static/chunks/node_modules_jspdf_dist_jspdf_es_min_c277e70f.js",
    "static/chunks/node_modules_html2canvas_dist_html2canvas_3938cdad.js",
    "static/chunks/node_modules_html2pdf_js_dist_html2pdf_min_7d356be9.js",
    "static/chunks/node_modules_5cf9c12c._.js"
  ],
  "source": "dynamic"
});
