(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_f0e4c1a2.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_f0e4c1a2.js",
  "chunks": [
    "static/chunks/[root of the server]__172b74a9._.css",
    "static/chunks/[root of the server]__e37e5976._.js",
    "static/chunks/node_modules_next_19927968._.js",
    "static/chunks/node_modules_@clerk_shared_dist_15eb4301._.js",
    "static/chunks/node_modules_swr_dist_d3931529._.js",
    "static/chunks/node_modules_@clerk_clerk-react_dist_7c5875f3._.js",
    "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
    "static/chunks/node_modules_b9cfa7c3._.js",
    "static/chunks/_61eeeae8._.js"
  ],
  "source": "dynamic"
});
