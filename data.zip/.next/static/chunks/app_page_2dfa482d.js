(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_2dfa482d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_2dfa482d.js",
  "chunks": [
    "static/chunks/_486e314d._.js"
  ],
  "source": "dynamic"
});
