(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_not-found_jsx_f72bda11._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_not-found_jsx_f72bda11._.js",
  "chunks": [
    "static/chunks/_97a3ca32._.js"
  ],
  "source": "dynamic"
});
