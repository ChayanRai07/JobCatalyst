(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_dashboard_page_jsx_f34d9522._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_dashboard_page_jsx_f34d9522._.js",
  "chunks": [
    "static/chunks/node_modules_lodash_20634561._.js",
    "static/chunks/node_modules_recharts_es6_f20eecd1._.js",
    "static/chunks/node_modules_28874525._.js",
    "static/chunks/_f4162a9f._.js"
  ],
  "source": "dynamic"
});
