(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_interview_page_jsx_f34d9522._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_interview_page_jsx_f34d9522._.js",
  "chunks": [
    "static/chunks/node_modules_lodash_20634561._.js",
    "static/chunks/node_modules_recharts_es6_7bff9f4c._.js",
    "static/chunks/node_modules_b39a01b4._.js",
    "static/chunks/_1e52b747._.js"
  ],
  "source": "dynamic"
});
