(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_f72bda11.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_f72bda11.js",
  "chunks": [
    "static/chunks/_486e314d._.js"
  ],
  "source": "dynamic"
});
