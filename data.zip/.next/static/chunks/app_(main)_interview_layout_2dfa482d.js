(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_interview_layout_2dfa482d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_interview_layout_2dfa482d.js",
  "chunks": [
    "static/chunks/node_modules_react-spinners_esm_cda55233._.js"
  ],
  "source": "dynamic"
});
